const db = require('../models');
const Bus = db.Bus;
const Booking = db.Booking;
const User = db.User;

exports.createBus = async (req, res) => {
  const bus = await Bus.create(req.body);
  res.json(bus);
};

exports.getBusBookings = async (req, res) => {
  const bookings = await Booking.findAll({
    where: { busId: req.params.id },
    include: [{ model: User, attributes: ['name', 'email'] }],
  });
  res.json(bookings);
};
