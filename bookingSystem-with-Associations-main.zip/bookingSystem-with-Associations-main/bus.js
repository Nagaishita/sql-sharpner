module.exports = (sequelize, DataTypes) => {
  const Bus = sequelize.define("Bus", {
    busNumber: DataTypes.STRING,
    totalSeats: DataTypes.INTEGER,
    availableSeats: DataTypes.INTEGER,
  });
  return Bus;
};
