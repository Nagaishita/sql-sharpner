const db = require('../models');
const Booking = db.Booking;

exports.createBooking = async (req, res) => {
  const booking = await Booking.create(req.body);
  res.json(booking);
};
