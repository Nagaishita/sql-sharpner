const Sequelize = require('sequelize');
const sequelize = require('../Config/db');

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

// Models
db.User = require('./user')(sequelize, Sequelize.DataTypes);
db.Bus = require('./bus')(sequelize, Sequelize.DataTypes);
db.Booking = require('./booking')(sequelize, Sequelize.DataTypes);

// Associations
db.User.hasMany(db.Booking);
db.Booking.belongsTo(db.User);

db.Bus.hasMany(db.Booking);
db.Booking.belongsTo(db.Bus);

module.exports = db;
