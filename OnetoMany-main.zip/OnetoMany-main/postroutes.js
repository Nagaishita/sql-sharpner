const express = require('express');
const router = express.Router();
const postController = require('../Controllers/PostController');

router.post('/', postController.createPost);
router.get('/:userId/posts', postController.getUserPosts);

module.exports = router;
