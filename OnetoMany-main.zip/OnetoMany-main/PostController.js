const db = require('../models');

exports.createPost = async (req, res) => {
  try {
    const { userId, title, content } = req.body;
    const post = await db.Post.create({ userId, title, content });
    res.status(201).json(post);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getUserPosts = async (req, res) => {
  try {
    const user = await db.User.findByPk(req.params.userId, {
      include: db.Post
    });
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
