const express = require('express');
const { User, Bus } = require('./models');
const app = express();

app.use(express.json());

// Create User
app.post('/users', async (req, res) => {
  const user = await User.create(req.body);
  res.json(user);
});

// Get Users
app.get('/users', async (req, res) => {
  const users = await User.findAll();
  res.json(users);
});

// Create Bus
app.post('/buses', async (req, res) => {
  const bus = await Bus.create(req.body);
  res.json(bus);
});

// Get Available Buses
app.get('/buses/available/:seats', async (req, res) => {
  const seatLimit = parseInt(req.params.seats);
  const buses = await Bus.findAll({ where: { availableSeats: { [require('sequelize').Op.gt]: seatLimit } } });
  res.json(buses);
});

app.listen(3000, () => console.log("Server started on port 3000"));
